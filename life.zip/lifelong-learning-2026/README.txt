PRAKASH VERMA — LIFELONG LEARNING 2026 PAGE

This is a separate, self-contained static website. The uploaded badge image is embedded in index.html.

To publish as a separate Vercel website:
1. Extract this ZIP.
2. In Vercel, create a NEW project (do not overwrite the earlier Prakash profile project).
3. Deploy the folder containing index.html as a static site.
4. Copy the new public URL.
5. Use that URL to create a separate QR code.

The page records only the visible badge details:
- Lifelong Learning 2026
- Issued to: Prakash Verma
- Issued by: BadgeClaimed
- Badge brand: CertiProf

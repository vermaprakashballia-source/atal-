PRAKASH VERMA — DIGITAL PROFILE WEBSITE

Files:
- index.html: complete responsive profile page. The badge image is embedded in the HTML.

IMPORTANT:
A QR code for Option B must point to a PUBLIC website address. A QR code cannot point to a file that exists only on your laptop.

Publish:
1. Open https://vercel.com/ and sign in.
2. Create a new project and import/upload this folder (or deploy it using Vercel's static-site flow).
3. Once deployed, copy the public URL (for example, https://your-project.vercel.app).
4. Use that exact URL to generate the final QR code. Do not use the example URL.

Profile wording:
- Contribution to AI for Space Mission.
- Represented Shidiswa Samwarddhan Gurukul (SSG) in connection with the Atal Innovation Mission.
- Location: Ballia, Uttar Pradesh, India — 277401.

Before publishing, verify the school name spelling and the exact wording of the representation claim with your school/mentor.
